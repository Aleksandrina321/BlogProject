package controller;

public @interface Authowired {
}
