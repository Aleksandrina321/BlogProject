package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import repository.RoleRepositiry;
import repository.UserRepository;

@Controller
public class UserController {

    @Authowired
    RoleRepositiry roleRepositiry;

    @Authowired
    UserRepository userRepository;

    @GetMapping("/register")
    public String register(Model model) {
        model.addAttribute("view", "user/register");

        return "base-layout";
    }
}
