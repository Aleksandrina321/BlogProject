package java.entity;

public class User {
}
